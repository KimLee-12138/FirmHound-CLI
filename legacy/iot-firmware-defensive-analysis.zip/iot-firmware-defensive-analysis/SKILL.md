---
name: iot-firmware-defensive-analysis
description: Analyze publicly available or locally authorized IoT firmware defensively and without prior vulnerability answers. Use when Codex must rapidly map Web routes, authentication boundaries and sensitive operations, select a small set of promising paths, trace static evidence to one highest-confidence security finding and root cause, or design and run non-weaponized robustness fuzzing against an isolated local parser, binary or harness. Never use for real-device or Internet scanning, firmware-service startup, exploitation, payload generation, authentication bypass, destructive testing, third-party requests or CVE reproduction.
---

# IoT Firmware Defensive Analysis

Analyze authorized local IoT firmware without knowing the vulnerability answer. Progressively narrow broad static evidence and optional isolated local robustness testing to one highest-confidence security finding and root cause:

```text
Entry/Route -> Source -> Transform -> Validation -> Authorization -> Sink
             -> Reachability -> Counterevidence -> Unknowns -> Conclusion
```

Do not validate a known vulnerability, reproduce a CVE, or stop at entry-point, string, symbol or dangerous-function inventories.

## Safety boundary

1. Process only public firmware or local firmware the user states is authorized.
2. Keep original firmware and extracted evidence read-only. Write only to separate analysis outputs, temporary copies and purpose-built local harnesses.
3. Do not execute extracted binaries for identification. Prefer headers, symbols, strings, configuration, call sites and disassembly.
4. Do not access networks, scan devices, start a real firmware service or send requests to any target.
5. Do not generate payloads, exploit requests, weaponized inputs, authentication bypass steps or code-execution tests.
6. Use placeholders such as `<USER_INPUT>`, `<BENIGN_MARKER>` and `<LOCAL_ONLY>` for suspicious inputs.
7. Separate direct evidence, inference, unknowns and public references. Freeze blind static findings before consulting public material.
8. Run fuzzing only against an isolated local parser, local binary or purpose-built harness under the rules in `references/offline-fuzzing.md`.
9. Automatically attempt deep decompilation, indirect-call resolution, validation analysis, authorization-dominance analysis, harness-fidelity checks, issue confirmation and severity assessment. Do not defer difficult analysis. Record an item under `remaining limitations` only after available local methods have been attempted and the evidence is unavailable because of missing tools, damaged samples, incomplete extraction, missing runtime configuration, unsupported architecture, failed decompilation or another concrete evidence-access barrier.
10. Never equate a crash or static confirmation with exploitability, remote reachability, unauthenticated access or a CVE match.
11. If the user asks for prohibited work, refuse that portion and continue with safe static evidence, local robustness testing, counterevidence or remediation.
12. Treat disassembly, decompilation, symbol resolution, cross-references, fuzz inputs and detailed traces as internal evidence. Do not paste long raw evidence into commentary, final answers or defensive reports. Store necessary raw intermediate evidence as local analysis artifacts and expose only artifact names plus sanitized summaries.

## Main workflow

### 1. Establish scope

Record authorization, exact local targets, allowed tools, prohibited actions, sample identity, prior artifacts and whether emulation is explicitly permitted. Record unknown values rather than inventing them.

### 2. Rapidly map the attack surface

Automatically identify, hash and extract the firmware into a separate work area, inventory the filesystem and executables, then map Web entries, routes, actual handlers, authentication boundaries and sensitive sinks. Collect enough breadth to rank paths; do not generate an exhaustive page-by-page or API-by-API report unless needed to resolve a candidate. Retry with available local extraction and analysis methods when the first method fails. Preserve only unresolved extraction failures and runtime-generated dependencies as `remaining limitations`.

Read [references/firmware-inventory.md](references/firmware-inventory.md) when identifying or extracting an image, inventorying a rootfs, interpreting ELF files, or mapping Web servers and routes.

### 3. Select a small candidate set

Rank paths by external-input evidence, route-to-handler confidence, authentication exposure, validation uncertainty, sensitive-operation impact and feasibility of resolving missing evidence. Select only a small working set, normally the top three. Record why each selected path outranks the rest; keep remaining items as brief observations.

Read [references/evidence-chain-method.md](references/evidence-chain-method.md) before analyzing authentication coverage, handler reachability, source-to-sink flow, validation, control dominance, counterevidence or conclusion confidence.

### 4. Deepen one path at a time

For each selected path, trace:

```text
Entry/Route -> Source -> Transform -> Validation -> Authorization -> Sink
            -> Reachability -> Counterevidence -> Missing evidence -> Conclusion
```

Resolve the most decision-changing unknown first using available local static-analysis methods, including symbols, strings, tables, cross-references, disassembly, decompilation and call/data-flow reconstruction. Do not stop because a step is difficult. Stop deepening a path when direct counterevidence defeats it, another candidate has materially stronger evidence, or all safe local methods have been exhausted and the precise blocker is recorded as a `remaining limitation`.

Before classifying or reporting any candidate, read and apply [references/evidence-model.md](references/evidence-model.md). Assign exactly one required conclusion category and emit the minimum evidence card defined there. Dangerous APIs, strings, dependencies, configuration keys or entry points without a data-flow hypothesis must remain `observation`.

### 5. Challenge, locally test when needed, and iterate

Actively try to disprove the current hypothesis. If static evidence is insufficient but the candidate remains promising and faithful isolation is locally feasible, automatically design and run a non-weaponized robustness test or fuzz harness. Use fuzzing only to observe local crashes, abnormal exits, memory errors, parser errors or denial-of-service behavior and to test a specific missing evidence link. If the harness cannot safely or faithfully run, record every attempted approach and the concrete blocker under `remaining limitations`; do not replace execution attempts with a recommendation. Read [references/offline-fuzzing.md](references/offline-fuzzing.md) completely before designing or running fuzzing.

Classify the path as `confirmed-issue`, `high-confidence-candidate`, `false-positive`, `unknown` or `observation`. If defeated, record the counterevidence, downgrade it, and move to the next candidate. A harness result supplements the evidence chain; it does not by itself prove route, authentication, production reachability or exploitability.

### 6. Select the primary finding

Compare surviving candidates and select exactly one primary finding with the strongest combined evidence and clearest root cause. Tie remediation to the failed or uncertain control. If none meets the confirmation gate, report the strongest candidate or `unknown`; do not force a vulnerability conclusion.

### 7. Report

Lead with one primary finding and its complete evidence card, root-cause explanation, counterevidence, automated-analysis results and remaining limitations. Summarize rejected or unresolved candidates only enough to show the narrowing process. If confirmation is impossible, explicitly report the highest-confidence candidate, completed automated analysis, excluded false positives, the concrete blocker and still-missing evidence. Items supported only by dangerous APIs or strings remain observations.

Use a defensive-summary presentation. Never include long disassembly/decompiler listings, raw fuzz cases, payloads, directly reproducible HTTP requests, attack steps or reusable trigger parameters. After analyzing a binary function, report only its role, parameter semantics, input source, key branches, validation/authentication logic, sensitive-operation type, summarized evidence chain, counterevidence and remaining limitations. For fuzzing, report only whether an anomaly occurred, its category, affected local component, input-field category, root-cause class and remediation. Keep exact samples and verbose traces out of chat and the final report.

Read [references/templates-and-reporting.md](references/templates-and-reporting.md) whenever producing persistent artifacts, candidate evidence cards, inventories, a formal report, remediation, automated-analysis/remaining-limitations sections or a final quality check.

## Reference routing

- Read [references/firmware-inventory.md](references/firmware-inventory.md) for acquisition facts, extraction, filesystem/ELF inventory, route discovery and inventory tables.
- Read [references/evidence-chain-method.md](references/evidence-chain-method.md) for source/transform/validation/authorization/sink analysis, connectivity, counterevidence, automatic resolution and remaining-limitations rules.
- Read [references/evidence-model.md](references/evidence-model.md) for mandatory conclusion categories, confirmation gates, hard judgment rules and the minimum evidence card. This reference is mandatory whenever analyzing, classifying, ranking or reporting any candidate or finding.
- Read [references/offline-fuzzing.md](references/offline-fuzzing.md) completely before proposing, building or running a local robustness fuzz harness. Do not read or use it for static-only tasks.
- Read [references/templates-and-reporting.md](references/templates-and-reporting.md) for output files, evidence-card templates, report structure, remediation format and delivery checklist.
- Do not use `references/local-validation.md` in this workflow: real firmware-service startup is outside scope.

Do not read every reference by default. Load only the files required by the current task. Any candidate requires `evidence-model.md` and `evidence-chain-method.md`; fuzzing requires `offline-fuzzing.md`; a formal deliverable requires `templates-and-reporting.md`.
