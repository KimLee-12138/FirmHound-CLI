# Isolated Local Robustness Fuzzing

## Purpose

Use fuzzing only to resolve a specific evidence gap in a promising candidate discovered without prior vulnerability knowledge. Test a local parser, local processing function, local binary or purpose-built harness. Do not start a real firmware service or reproduce a known vulnerability.

## Mandatory safety boundary

1. Operate only on a local sample the user states is authorized.
2. Keep original firmware and extracted rootfs read-only. Build and run only in a disposable temporary directory, container, VM or equivalent sandbox.
3. Disable networking for the harness and child processes. Do not bind or connect sockets, resolve remote names, scan devices or send requests.
4. Do not start init, Web servers, daemons or the full firmware.
5. Remove or stub process execution, shell invocation, file deletion, configuration/NVRAM writes, flash/device access, reboot, privileged ioctls and other state-changing sinks.
6. Use structured benign seeds derived from locally observed input grammar. Use `<BENIGN_MARKER>` in documentation; do not preserve weaponizable bytes or request syntax in reports.
7. Do not import known PoCs, exploit corpora, CVE details, patch diffs or target-answer signatures before freezing the blind result.
8. Stop if the harness attempts network access, privileged device access, external process execution or writes outside its disposable directory.

## Preconditions

Before running, record:

- explicit local authorization and target artifact;
- candidate evidence card and the exact missing fact fuzzing will test;
- harness boundary and why it represents the target parser/function;
- disabled or stubbed side effects;
- sandbox, resource limits, timeout and stop procedure;
- oracle and expected evidence;
- output directory and cleanup plan.

If faithful isolation or side-effect removal cannot be demonstrated, first attempt safer local alternatives such as extracting the parser boundary, stubbing dependencies, using a disposable container/VM or building a minimal faithful harness. If none is feasible, preserve the harness design, attempted approaches and concrete blockers under `remaining limitations`, and classify the missing evidence as `unknown`.

## Allowed targets and oracles

Allowed targets:

- an extracted local parser or decoder;
- a locally callable processing function;
- a local binary invoked without network or device capabilities;
- a minimal recompiled or emulated harness containing only required parsing logic;
- a toy surrogate only for testing harness mechanics, never as target evidence.

Analyze and preserve internally as needed, but expose only:

- crash and signal category;
- abnormal exit or timeout;
- sanitizer-reported memory error category;
- parser rejection, inconsistent state or assertion category;
- whether the result reproduced locally, without showing the reproducing sample;
- triggering-condition summary by field category, size/range class, structure and transformation stage;
- affected local component, root-cause class and defensive remediation.

Do not expose raw or minimized fuzz cases, corpus bytes, payload construction, directly reproducible request formats, reusable trigger parameters, attack steps, exploitability or instruction-pointer-control details. Store exact local cases and verbose traces only in a restricted local evidence artifact when needed for deduplication or remediation verification; user-facing output may cite only the artifact name and sanitized summary.

## Harness workflow

1. Choose one candidate and one decision-changing hypothesis.
2. Isolate the smallest parser/function boundary that accepts the relevant input class.
3. Replace dangerous sinks with logging stubs and constrain filesystem access to the temporary directory.
4. Create the smallest valid benign seed corpus from local grammar evidence.
5. Mutate structure, length, count, type, encoding and nesting without adding commands, executable content or attack strings.
6. Apply CPU, memory, file-size, process-count and wall-time limits.
7. Capture exit status, sanitizer diagnostics and deterministic parser output.
8. Deduplicate and minimize failures while preserving only non-weaponized local artifacts.
9. Map a reproducible failure back to the static function/basic block and relevant missing validation.
10. Search for counterevidence, including harness artifacts, unrealistic state, missing initialization and behavior absent from production code.
11. Update the evidence card. Treat an unmapped crash as a robustness observation or candidate, not a confirmed root cause.

## Interpretation rules

- A crash proves only that the isolated local target failed for the recorded input class under the harness conditions.
- A timeout may indicate algorithmic complexity, deadlock, blocking I/O or an inaccurate harness; distinguish them before claiming denial-of-service risk.
- Automatically trace a sanitizer report through allocation, bounds, lifetime and calling context. If symbols, architecture support or required runtime state prevent that mapping after available local methods are attempted, record the precise gap under `remaining limitations`.
- A parser error without unsafe behavior is normally counterevidence or an expected rejection.
- A local failure does not prove Web-route reachability, authentication state, production configuration, remote impact or exploitability.
- Confirm a root cause only when fuzz evidence maps to the same code path and failed control established by static evidence.

## Defensive output template

```markdown
## Local robustness test

- Authorization and local target:
- Candidate and hypothesis:
- Harness boundary:
- Isolation and network disabled:
- Stubbed side effects:
- Seed grammar source:
- Mutation dimensions:
- Resource limits:
- Oracle:
- Result category:
- Local reproducibility: yes / no / inconclusive; no sample shown
- Affected local component:
- Input-field category:
- Crash or anomaly type:
- Root-cause class:
- Static code-path summary:
- Counterevidence and harness limitations:
- Evidence-chain effect:
- Defensive remediation:
- Local evidence artifact: <artifact name or not-saved>
- Automated analysis performed:
- Remaining limitations:
- Cleanup status:
```
