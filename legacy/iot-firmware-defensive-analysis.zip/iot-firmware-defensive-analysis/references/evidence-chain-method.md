# Static Evidence-Chain Method

## Contents

1. Evidence vocabulary
2. Authentication and authorization analysis
3. Source-to-sink analysis
4. Connectivity strength
5. Counterevidence analysis
6. Candidate selection and iteration
7. Automatic completion and remaining limitations

## 1. Evidence vocabulary

Tag individual facts as:

- `confirmed`: directly supported by a file, configuration, symbol, instruction, call graph or preserved artifact;
- `inferred`: supported by multiple related facts but not directly demonstrated;
- `unknown`: absent, incomplete or ambiguous evidence;
- `external-reference`: learned from public material after blind static findings were frozen.

Keep direct evidence and inference separate. Cite file paths, configuration keys, function names and concise location references. Use only minimal instruction-level references needed to support the conclusion; do not reproduce long instruction or decompiler listings in user-facing output.

Raw disassembly, decompiler output, symbol dumps, cross-reference tables and data-flow traces are internal evidence. If preservation is useful, save them under the separate local evidence directory and cite the artifact name plus a defensive summary. Do not display the raw artifact in chat or the final report.

## 2. Authentication and authorization analysis

Map:

- perimeter Basic/Digest auth, cookies, proxies and ACLs;
- authentication exceptions and public, wizard, factory or test paths;
- internal login, session validity/freshness, roles and action/object authorization;
- initialization, operating mode, NVRAM, feature and production-state gates;
- policy applied to original versus rewritten URI;
- behavior when credentials, configuration or state are absent.

Determine whether each check merely exists or controls every feasible path to the sink. Verify that failure returns before the sink and defaults to denial. An authentication exception is not proof of unauthenticated access.

Boundary table:

```markdown
| Entry | Perimeter control | Exception | Internal auth | Role/action/object control | State gate | Dominates sink? | Evidence | Unknowns |
```

## 3. Source-to-sink analysis

### Sources

Consider query strings, form/POST, multipart, XML/JSON, cookies, headers, CGI variables, URI/path segments, filenames, IPC, configuration and files populated by an external interface.

### Transforms and validation

Record operations in execution order:

- parsing, decoding, canonicalization, concatenation and format conversion;
- schema, type, range, count, length and allocation-size checks;
- allowlists, forbidden characters, escaping and special-character handling;
- path joining, traversal removal, symlink handling and canonicalization;
- defaults, truncation, integer conversion and error behavior.

Verify validation occurs after final decoding/normalization. For memory operations, examine allocation, copy length, integer width/sign and terminator semantics. For filesystem operations, examine canonicalization, root confinement and symlink resolution before authorization.

### Authorization

Record perimeter auth, internal session, role/action/object ownership, state gates, default-deny behavior and whether these controls dominate the sink.

### Sinks

Consider:

- process creation: `system`, `popen`, `exec*` and vendor wrappers;
- string/memory: `sprintf`, `snprintf`, `strcpy`, `strcat`, `memcpy`, `memmove` and length-bearing wrappers;
- file/configuration: open, write, rename, unlink, archive extraction and NVRAM/configuration APIs;
- device/firmware: flash writes, reboot/reset, service control and privileged ioctls.

## 4. Connectivity strength

Report the strongest demonstrated level:

1. instruction/basic-block definition-use chain;
2. interprocedural call and argument flow;
3. handler-level flow supported by multiple artifacts;
4. route/function inference with missing data edges;
5. co-occurrence only.

Levels 4–5 cannot independently confirm source-to-sink flow. Never convert symbol, string or dependency co-occurrence into a connected chain.

## 5. Counterevidence analysis

Before promotion, try to disprove the hypothesis:

1. Is the value externally controllable or constant/internal?
2. Is the route production-reachable or test/dead code?
3. Does another authentication, action or object check apply after rewriting?
4. Does effective validation occur after final decoding and normalization?
5. Do length checks cover allocation, copy, integer and terminator semantics?
6. Does path authorization occur after canonicalization and symlink resolution?
7. Does the sink receive external data or a safe derived constant?
8. Do all failure paths return before the sink and default to denial?
9. Is the call only framework, startup or maintenance code?
10. Is the hypothesis based only on a symbol, string, dependency or public advisory?

Record explicit counterevidence and pass the resulting evidence to the mandatory classification rules in `evidence-model.md`. Do not assign a conclusion from this method alone.

## 6. Candidate selection and iteration

After rapid surface mapping, score paths comparatively rather than exhaustively documenting all of them. Prefer paths with:

- a route tied to an actual handler;
- a recognizable external-input source;
- a high-impact local sink or privileged operation;
- weak, ambiguous or incorrectly ordered validation/authorization;
- evidence that can be resolved through static analysis or a safe local harness.

Select normally no more than three active candidates. For each iteration:

1. Identify the single missing fact most likely to change the classification.
2. Gather static evidence for that fact first.
3. If static evidence cannot resolve it and robustness testing is appropriate, use `offline-fuzzing.md`.
4. Search for counterevidence before promotion.
5. Downgrade defeated paths and replace them with the next ranked observation.
6. Stop when one path clearly dominates or remaining paths cannot be resolved within scope.

Do not use a known vulnerability answer, CVE description, patch diff, PoC, exploit signature or expected handler as a selection hint during blind analysis. Keep any ground truth outside the Agent's accessible artifacts until the result is frozen.

## 7. Automatic completion and remaining limitations

The AI must attempt to resolve every material evidence link before declaring it unavailable. Automatically use applicable local methods for:

- stripped function boundaries, handler/action tables and indirect calls;
- exact variable definition-use chains, aliasing and calling conventions;
- decoding, canonicalization and validation semantics;
- authentication/authorization dominance over the sink;
- error-path default-deny behavior;
- NVRAM, device-state and production-mode reachability;
- fuzz harness fidelity, sanitizer interpretation, crash deduplication and root-cause mapping;
- conclusion classification and severity assessment.

Do not defer an item merely because it requires deep disassembly, decompilation, custom cross-reference reconstruction or multiple local tools. When static evidence remains insufficient, automatically use a safe isolated robustness test when the rules in `offline-fuzzing.md` can be met.

Record an unresolved item under `remaining limitations` only when a concrete barrier remains after documented attempts, such as:

- a required tool is unavailable and no local substitute works;
- the sample is damaged or a required file failed extraction;
- runtime-generated configuration, device state or dependency data is absent;
- the architecture or binary format is unsupported by available analysis tools;
- disassembly/decompilation or indirect-call resolution fails despite alternative local methods;
- a faithful harness cannot be isolated or required evidence cannot otherwise be obtained within the safety boundary.

For every remaining limitation, state what was attempted, why it failed, what exact evidence is missing and how the missing fact affects classification. Never substitute a future-work recommendation for attempting the analysis now.

Never automate Internet or device scanning, real-device requests, firmware-service startup, unsafe configuration changes, uploads, destructive diagnostics, exploit validation or public-PoC replay.

## 8. Function-analysis summary

After resolving a binary function, expose only this defensive summary:

```markdown
- Function role:
- Parameter semantics:
- Input source:
- Key branches:
- Validation and authentication:
- Sensitive-operation type:
- Evidence-chain conclusion: Source -> Transform -> Validation -> Authorization -> Sink
- Counterevidence:
- Remaining limitations:
- Local evidence artifact: <artifact name or not-saved>
```

Do not include long disassembly, raw decompiler text, register-by-register walkthroughs, attack-oriented trigger values or reproduction steps. A short function name, address or offset may be included only as a location reference and not as an executable recipe.
