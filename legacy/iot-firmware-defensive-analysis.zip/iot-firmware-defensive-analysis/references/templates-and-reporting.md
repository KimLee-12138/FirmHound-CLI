# Templates and Reporting

## Contents

1. Suggested output files
2. Evidence-card usage
3. Primary finding and candidate disposition
4. Report format
5. Remediation format
6. Delivery quality checklist

## 1. Suggested output files

Create persistent artifacts only when requested:

```text
analysis/<stage>/firmware-facts.md
analysis/<stage>/filesystem-summary.md
analysis/<stage>/web-entry-inventory.md
analysis/<stage>/auth-boundary-map.md
analysis/<stage>/sensitive-call-index.md
analysis/<stage>/dataflow-candidates.md
analysis/<stage>/risk-ranking.md
analysis/<stage>/false-positive-review.md
evidence/<stage>/tool-logs.md
evidence/<stage>/raw-static-evidence.txt
evidence/<stage>/fuzz-results-local-only/
reports/iot-firmware-defensive-audit.md
```

Do not create empty conclusions or evidence files. Record `not-run`, `unavailable` or the precise extraction limitation. Raw static traces and exact fuzz cases are local-only intermediate artifacts: do not quote or embed them in chat or reports.

## 2. Evidence-card usage

Use the complete minimum evidence card from `evidence-model.md` for every candidate or finding. Every P1/P2 item must populate every field. An item supported only by a dangerous API, string, dependency, configuration key or entry name belongs only in `observation`.

## 3. Primary finding and candidate disposition

Lead with exactly one primary finding. If no candidate meets the confirmation gate, label the primary result `high-confidence-candidate` or `unknown` rather than forcing an issue.

```markdown
## Primary Finding

| Candidate | Classification | Root-cause class or hypothesis | Evidence-chain strength | Counterevidence | Decisive missing evidence |
|---|---|---|---|---|---|
```

Summarize other investigated paths as dispositions rather than full findings unless needed to justify selection:

```markdown
| Candidate | Why selected | Final disposition | Defeating or limiting evidence | Why it did not outrank the primary finding |
```

Keep priority separate from confidence. Group candidates by classification before sorting by priority.

## 4. Report format

```markdown
# IoT Firmware Defensive Evidence and Robustness Report

## 1. Scope, authorization and prohibited actions
## 2. Sample identity, integrity and extraction limitations
## 3. Filesystem and architecture inventory
## 4. Web services and route-to-handler map
## 5. Authentication, authorization and state boundaries

## 6. Primary Finding
Use the complete evidence-model card and explain the root cause.

## 7. Local Robustness Testing
Include the offline-fuzzing result template when fuzzing was performed; otherwise state `not-run` and why.

## 8. Candidate Disposition
Summarize rejected, unresolved and observational paths.

## 9. Remediation mapped to failed controls
## 10. Automated analysis results and remaining limitations
## 11. External-reference comparison
## 12. Safety boundary and conclusion limitations
```

Do not hide failed tools, extraction gaps, counterevidence or unknowns. In section 10, record what the AI attempted, which alternatives were tried, why any item remains unresolved, the exact missing evidence and its effect on classification. Do not turn difficult steps into deferred recommendations. Keep public references separate from independently collected evidence.

Write the report as defensive conclusions and evidence summaries, not as a reverse-engineering transcript. Function-level reporting must summarize role, parameter semantics, source, key branches, validation/authentication, sensitive-operation type, evidence-chain conclusion, counterevidence and remaining limitations. Cite local raw evidence by artifact name only.

Never include long disassembly/decompiler blocks, raw fuzz cases, payloads, reproducible HTTP requests, attack steps or reusable trigger parameters. Avoid assembling many individually harmless low-level details into a reproduction recipe. Use semantic field categories and placeholders instead of exact suspicious values.

## 5. Remediation format

Tie each recommendation to evidence:

```markdown
| Candidate/control | Evidence of failure or uncertainty | Defensive change | Verification evidence required |
```

Prefer default-deny authentication, action/object authorization, schema/allowlist validation, safe process APIs, canonicalize-then-authorize path handling, least privilege, isolation and security logging as applicable. Do not claim a fix is necessary when the underlying candidate remains an unsupported observation.

## 6. Delivery quality checklist

- [ ] Authorization, hashes, extraction failures, permissions and symlinks are recorded.
- [ ] Every route maps to an actual handler or is marked unresolved.
- [ ] Runtime-generated configuration and production state are not assumed.
- [ ] Every candidate covers source, transform, validation, authorization and sink, or marks missing segments.
- [ ] Decoding/normalization order and length/allocation semantics are considered.
- [ ] Authentication existence is distinguished from control dominance.
- [ ] Every P1/P2 item records counterevidence and decisive missing evidence.
- [ ] Every P1/P2 item uses the complete evidence-model card with no omitted fields.
- [ ] Exactly one primary finding is selected, or the report explicitly states that no candidate is sufficiently supported.
- [ ] Rejected candidates record why they were downgraded and why they do not outrank the primary finding.
- [ ] Dangerous imports, strings and public advisories are not treated as connected flows.
- [ ] API/string-only items appear only under `observation`.
- [ ] Every `confirmed-issue` satisfies all confirmation gates after automatic counterevidence and alternative-path analysis.
- [ ] Every `false-positive` has direct defeating evidence.
- [ ] Unknowns are preserved rather than silently filled.
- [ ] Static-analysis gaps were automatically pursued with available local tools and, when safe and faithful, isolated robustness testing.
- [ ] Remaining limitations state attempted methods, the concrete blocker, exact missing evidence and classification effect; none merely delegates a difficult step.
- [ ] External references are separated from independent findings.
- [ ] Remediation maps to demonstrated or uncertain controls.
- [ ] Output contains no exploit, payload, bypass procedure or triggerable request.
- [ ] Output contains no long disassembly/decompiler listing, raw fuzz case, reusable trigger parameter or attack-oriented reproduction sequence.
- [ ] Binary-function results use the defensive function-summary fields instead of a reverse-engineering transcript.
- [ ] Detailed intermediate evidence is local-only and referenced by artifact name plus summary.
- [ ] Any fuzzing used an offline disposable harness, no network or firmware service, stubbed dangerous sinks and reported only non-weaponized robustness evidence.

If an item fails, correct the report, document missing evidence or downgrade the affected conclusion before delivery.
