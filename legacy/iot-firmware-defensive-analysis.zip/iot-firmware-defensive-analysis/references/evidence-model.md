# Candidate and Finding Evidence Model

## Contents

1. Mandatory classification
2. Confirmation requirements
3. Hard judgment rules
4. Minimum evidence card
5. Completeness and downgrade rules

## 1. Mandatory classification

Assign every candidate or finding exactly one conclusion category. Do not leave a candidate as an unclassified list entry.

### `confirmed-issue`

Use only when static evidence proves all of the following:

- the entry and actual handler are reachable in the relevant production configuration;
- the external input is controllable;
- the relevant security constraint is absent, insufficient or incorrectly ordered;
- the input reaches a sensitive sink through a demonstrated data flow;
- no authentication, validation, default-deny, failure-path or unreachability evidence remains that could overturn the conclusion.

State the confirmed security-problem class explicitly, such as:

- missing authentication;
- missing role, action or object authorization;
- insufficient input validation;
- incorrect path-normalization and authorization order;
- controllable memory-length misuse;
- reachable dangerous operation.

`confirmed-issue` does not automatically mean confirmed exploitability, remote reachability, unauthenticated access, a CVE match or completed dynamic validation. State those properties separately and mark them `unknown` unless independently evidenced.

### `high-confidence-candidate`

Use when multiple static artifacts connect Source, Transform, Validation, Authorization and Sink, but a decisive fact is still missing. Examples include exact control flow, definition-use continuity, filter semantics, authentication/authorization dominance, an indirect-call target, or runtime/production configuration and state.

Name the single most decisive missing fact that prevents confirmation.

### `false-positive`

Use only when direct counterevidence defeats the hypothesis. Examples include:

- the apparent input is constant or internally generated;
- the entry or branch is unreachable;
- effective validation constrains the value before the sink;
- an applicable permission check defaults to denial and dominates the sink;
- every failure path returns before the sink;
- external input cannot reach the sink.

Record the exact defeating evidence. Absence of supporting evidence alone is not a false positive.

### `unknown`

Use when available evidence cannot construct or reject a meaningful hypothesis because extraction is incomplete, files or metadata are missing, indirect calls cannot be resolved, or runtime-generated configuration, NVRAM, feature state or production mode is unavailable.

State what evidence would resolve the unknown.

### `observation`

Use when analysis has found only a dangerous API, string, dependency, configuration item, functional entry or public reference and has not formed a defensible data-flow hypothesis.

Observations may guide later automated analysis, but they are not issues or high-confidence candidates.

## 2. Confirmation requirements

Require all material gates before assigning `confirmed-issue`:

```text
reachable entry and actual handler
+ production/runtime relevance
+ controllable external source
+ connected Source -> Transform -> Validation -> Authorization -> Sink flow
+ demonstrated absence, weakness or incorrect ordering of the relevant control
+ sensitive sink
+ reviewed counterevidence with no decisive contradiction
```

If any unresolved fact could materially reverse the conclusion, use `high-confidence-candidate` or `unknown`. If only isolated indicators exist, use `observation`.

Keep three dimensions separate:

- fact status: `confirmed`, `inferred`, `unknown`, `external-reference`;
- conclusion category: the five categories in this reference;
- analysis priority: `P1`, `P2` or `P3`.

High priority does not imply confirmation. Strong confidence does not by itself establish impact or exploitability.

Use priority as automatic-analysis urgency:

- `P1`: prioritize immediately because a reachable or plausibly reachable high-impact sink is adjacent to a decisive validation or authorization uncertainty;
- `P2`: investigate after P1 because a credible chain exists but reachability, control coverage or impact remains materially limited;
- `P3`: retain as a low-evidence observation, unresolved background item or low-impact analysis task.

## 3. Hard judgment rules

Apply every rule:

1. A dangerous API import is not issue evidence.
2. Page existence does not prove handler reachability.
3. An authentication exception does not prove unauthenticated access.
4. A parameter name coexisting with a command string does not prove data-flow connectivity.
5. A filtering function existing does not prove effective filtering.
6. An authentication function existing does not prove it controls the sensitive operation.
7. Ordinary-page reachability does not prove dynamic-handler or dangerous-action reachability.
8. Public vulnerability material cannot be presented as an independent finding.
9. Every downgrade or exclusion must record explicit counterevidence.
10. Insufficient evidence must stop at `high-confidence-candidate`, `observation` or `unknown`; do not announce a vulnerability.
11. Items containing only dangerous APIs, strings, dependencies, configuration keys or entry names must be `observation`.
12. `false-positive` requires defeating evidence; uncertainty alone requires `unknown` or candidate status.

## 4. Minimum evidence card

Emit one UTF-8 Markdown evidence card for every candidate or finding. Use ordinary Markdown headings and lists; do not use box-drawing characters or terminal-art tables.

```markdown
### CAND-XX: <short defensive title>

- Candidate ID:
- Conclusion classification: confirmed-issue / high-confidence-candidate / false-positive / unknown / observation
- Priority: P1 / P2 / P3
- Confirmed problem class: not applicable / <problem class>
- Entry and route:
- Actual handler:
- Input source: <USER_INPUT>
- Semantic variable:
- Parsing/decoding:
- Data transformations:
- Length limits:
- Type/range limits:
- Allowed characters or schema:
- Path normalization:
- Defaults and error handling:
- Perimeter authentication:
- Internal authentication:
- Role/action/object authorization:
- State-machine conditions:
- Does the check dominate the sink?:
- Sensitive call:
- Data-flow connectivity:
- Runtime/production configuration reachability:
- Direct evidence:
- Evidence summary artifact:
- Inferences:
- Counterevidence:
- Missing evidence:
- Why this can or cannot be confirmed:
- Automated analysis performed:
- Remaining limitations:
```

For `confirmed-issue`, replace `not applicable` in `Confirmed problem class` and identify the failed control. Do not add exploit inputs, payloads, attack requests or bypass instructions.

Populate `Direct evidence` as a concise defensive summary. Do not paste raw disassembly, decompiler output, fuzz cases, request syntax or trigger values. When detailed evidence must be preserved, place it in a local artifact and populate `Evidence summary artifact` with only its local name/path and a one-sentence description.

## 5. Completeness and downgrade rules

- Every P1/P2 candidate must use the complete evidence card without omitted fields.
- For P3 observations, retain all fields but use `not established` or `unknown` rather than inventing a chain.
- Populate counterevidence for every category. Use `none found after <scope>` only after an active, recorded search.
- Populate missing evidence for all categories, including confirmed issues when residual scope limitations exist.
- Populate `Automated analysis performed` with the tools and reasoning stages actually attempted. Populate `Remaining limitations` only with concrete evidence-access barriers after safe local alternatives have been exhausted; use `none` when no such barrier remains.
- Explain why the selected category fits and why adjacent stronger/weaker categories do not.
- Reclassify when new evidence changes reachability, controllability, validation, authorization, connectivity or production relevance.
- Never preserve an inflated initial classification for continuity with an earlier report.
- Use `observation` for an isolated fact with no concrete data-flow hypothesis. Use `unknown` when a concrete hypothesis exists but missing artifacts or runtime state prevent supporting or rejecting it. If both apply, record the isolated fact as an observation and the blocked hypothesis as a separate unknown candidate.
