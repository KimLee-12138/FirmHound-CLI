# Firmware Inventory and Web Mapping

## Contents

1. Required inputs
2. Firmware identification and extraction
3. Rootfs and ELF inventory
4. Web service and route mapping
5. Inventory output schemas

## 1. Required inputs

Record:

| Input | Required record |
|---|---|
| Authorization | Local path, authorization statement, allowed tools and emulation permission |
| Sample | Firmware image or unpacked rootfs path |
| Identity | Vendor, model, hardware revision, version, source and date |
| Integrity | Size and SHA-256 of original samples |
| Extraction | Tools, offsets, errors, permissions and symlink preservation |
| Environment | Host OS, architecture and isolation constraints |
| Prior material | Logs, reports, decompiler notes and screenshots |
| Public material | Use only after freezing blind findings; label `external-reference` |

Mark unknown values as `unknown`; do not infer identity or version from an unverified filename alone.

## 2. Firmware identification and extraction

1. Calculate file size and SHA-256 before extraction.
2. Cross-check magic, headers, offsets, extraction results and directory characteristics. Do not confirm a format from a single tool label.
3. Identify U-Boot or vendor containers, compression, kernel, bootloader, rootfs, configuration and Web-resource regions.
4. Check SquashFS, CPIO, tar, UBIFS, JFFS2, CRAMFS and relevant vendor variants.
5. Preserve the original. Extract to a separate output directory or temporary copy.
6. Keep a browsing copy and, when possible, an evidence copy preserving permissions, ownership, symlinks and devices.
7. Record failed blocks, missing files, unsupported compression, lost metadata, unresolved links and device nodes not recreated.
8. Propagate incomplete extraction into later reachability and issue conclusions.

Record tool versions, command categories, errors and exit codes. Never hide fallback-tool use or partial extraction.

## 3. Rootfs and ELF inventory

Inventory:

- root directories and their apparent roles;
- regular files, directories, symlinks, device nodes, FIFOs and sockets;
- ELF files, scripts, configurations, certificates and Web resources;
- CPU architecture, word size, endianness, ABI and instruction-set revision;
- ELF interpreter, libc, shared dependencies, stripped status and build identifiers;
- kernel modules, vendor libraries and privileged helper programs;
- runtime-generated files and links into `/tmp`, `/var`, NVRAM or mounted storage.

Identify Web servers without executing extracted programs. Look for Lighttpd, GoAhead, Boa, uHTTPd, Nginx, Apache and vendor dispatchers in binaries, startup scripts and configuration.

## 4. Web service and route mapping

Inspect at least:

```text
/www /htdocs /web /cgi-bin /https
/usr/sbin /usr/bin /bin /sbin
/etc /etc/init.d /etc/rc.d
Web configurations, module lists, startup scripts and rewrite rules
```

For every possible entry:

1. Resolve the visible file or URI through extension mapping, CGI assignment, alias, rewrite, symlink, wrapper and dispatcher action table.
2. Record the actual binary, script, function and address when evidenced.
3. Corroborate reachability using configuration, page/form/JavaScript references, handler tables or call sites.
4. Distinguish production, optional-feature, initial-setup, factory/test and apparently dead routes.
5. Record HTTP method and content type only when evidenced.
6. Record vendor-library dependencies and runtime-generated configuration dependencies.
7. Keep zero-length and redirect-only files when a routing rule maps them to a handler.
8. Do not infer dynamic-handler reachability from an ordinary static page.

## 5. Inventory output schemas

Firmware facts:

```markdown
| Vendor | Model | Revision | Version | Size | SHA-256 | Container | Filesystem | CPU | Evidence status |
```

Extraction limitations:

```markdown
| Artifact/region | Tool | Result | Missing metadata/files | Downstream effect |
```

Web services:

```markdown
| Service | Version | Binary | Config | Document root | Bind/port | Identity | Runtime unknowns |
```

Routes:

```markdown
| URI | Visible file | Actual handler | Route evidence | Function | Production reachability | Auth summary | Unknowns |
```

Do not create empty evidence files. In a report, use `not-run` or `unavailable` for absent work.
