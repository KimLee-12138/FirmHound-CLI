# Loopback-Only Local Validation

Read and apply this reference only after the user explicitly authorizes service startup. Static-only authorization does not permit this workflow.

## Preconditions

- Use QEMU, a VM, Docker or equivalent isolation with a disposable rootfs copy or snapshot.
- Disable external networking; bind only to `127.0.0.1:<LOCAL_ONLY>`.
- Use a non-privileged port.
- Record enabled and disabled modules, startup command category, stop procedure and log locations.
- Identify candidate endpoints in advance and prohibit all access to them.

## Allowed validation

1. Check ELF architecture, interpreter and libraries.
2. Check configuration syntax without contacting a service.
3. Create harmless runtime placeholder directories/files without credentials or state-changing capability.
4. Start a minimal service configuration.
5. Observe process state and loopback listening.
6. Access only an ordinary side-effect-free page without parameters.
7. Preserve response status, logs and screenshots when requested.
8. Stop the service and confirm the listener closed.

## Prohibited validation

Do not access candidate endpoints; send query parameters or POST data; upload files; invoke diagnostics; write configuration; mutate NVRAM; trigger file deletion, process execution, reboot or firmware operations; validate code execution; listen externally; connect to a real device or the public Internet.

Ordinary-page reachability proves only that the base service can respond. It does not prove dynamic-handler, authentication, authorization or candidate reachability.

## Result template

```markdown
- Explicit authorization:
- Isolation method and disposable copy:
- Architecture/interpreter:
- Bind and port: 127.0.0.1:<LOCAL_ONLY>
- Enabled modules:
- Disabled modules:
- Startup status:
- Ordinary page and status:
- Logs/screenshots:
- Missing runtime files/state:
- Stop status:
- Listener closed:
- Candidate endpoints not accessed:
- Unvalidated items:
```
